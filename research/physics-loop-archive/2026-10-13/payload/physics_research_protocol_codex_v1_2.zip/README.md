# 高价值物理发现 Loop · Codex 宿主协议 v1.2

日期：2026-10-13。

**交付的是可供宿主读取的研究执行协议，不是新运行时。** Codex 或其他具备工具能力的 Agent 负责模型、检索、终端与会话任务；协议规定研究方向、前置审查、分阶段投入、证据与查新、续跑和成果条件。没有控制器、API 客户端、服务器、数据库、自动定时器或训练代码。

## 放在哪里

推荐只用于一个专用课题目录，不修改全局配置：

```text
新课题目录/
├── AGENTS.md
├── START.md
├── README.md
├── .agents/
│   └── skills/
│       └── physics-discovery-loop/
│           ├── SKILL.md
│           └── references/
│               ├── review.md
│               └── research-judgment.md
└── research/                 # 实际开始研究时按需产生；本包不放虚假日志
    ├── STATE.md
    ├── DECISIONS.md
    ├── LITERATURE.md
    └── artifacts/
```

Codex 官方文档说明，AGENTS.md 在启动时按项目路径加载，项目内 `.agents/skills` 可提供带 `name`、`description` 的 SKILL.md。技能可以只有指令，无需脚本。[1][2]

将本包内容复制到**新课题目录**，保留隐藏的 `.agents` 目录，在该目录打开新宿主会话，然后使用 [START.md](START.md) 的提示即可。解压本包不会自动安装或运行研究。

既有仓库已有 AGENTS.md 时，不覆盖；阅读原规则，将本包的研究约定合并到适当项目范围，或采用直接读取 SKILL.md 的入口。不要自行覆盖 AGENTS.override.md 或修改用户全局指令、安全/审批/联网设置。同名技能需检查冲突。本包不能保证未检查的本地版本如何加载，实际入口按 START.md 核对。

其他 Agent 宿主不必支持技能发现，只需在启动提示中明确读取 SKILL.md；工具名、联网和会话持久性按其实际能力处理。

## 实际研究方式

```text
领域与边界 → 定向读前作 → 候选“问题＋路径＋下一行动”
                           ↓
                  必要前审与分阶段决定
           CLOSE/PARK ←─┼─→ PROBE → 回审查
                         └→ ADVANCE → 实际研究
                                           ↓
                           正确性＋方法/结果查新＋物理贡献
                                           ↓
                                 续投／改题／分叉／关闭
```

首次前审采用 [review.md](.agents/skills/physics-discovery-loop/references/review.md)。专家式问题表征与能力形成只按 [research-judgment.md](.agents/skills/physics-discovery-loop/references/research-judgment.md) 服务实际障碍，不单独成为训练主线。

**审查是宿主必须遵循的研究行为，不是操作系统强制门禁。** 本包不包含拦截器，也不提供不可篡改日志、程序级预算锁、exactly-once 或自动恢复保证。若需要这些能力，属于另外的软件工程任务，不把它们隐含在“协议搭好”里。

## 已完成和未完成

已完成：将此前设计与最新“执行前审查问题、解法及投入”的要求，改为可直接读取的项目级指令与纯指令技能；提供启动、续跑与前审入口；检查包内引用、技能头和文件完整性。

未完成：没有在用户的 Codex 中安装、试运行或验收；没有启动新课题，没有新物理成果；没有外部模型调用、Git 提交、云部署或后台作业。格式和文件检查不是宿主行为验收，也不是研究能力验证。

此前意外进入的运行时方案不属于本交付。这个压缩包只有协议与其静态检查记录，不依赖旧实验代码，也不复制旧研究结论作为已验证的训练数据。

## 从 v1.0 的实质改动

将“选中问题就研究”替换为“审查问题＋路径＋下一行动，只批准下一阶段投入”。

取消另建控制器/API 的要求，使用宿主原生项目指令与技能。必要的科研脚本仍可由宿主在研究中按需编写。

心智模型以实际表征、预测和转向体现，不强制生成卡片；能力形成只服务真实瓶颈。查新分别约束问题、方法与结果，并在投入扩大或命题改变时定向更新，避免无效重复。

## 官方宿主格式依据

以下仅支持文件加载与技能格式，不证明本科研方法有效。核对日期：2026-10-13。入口发生官方重定向，均保留以便复核。

[1] OpenAI, Custom instructions with AGENTS.md.
https://developers.openai.com/codex/guides/agents-md/
核对时重定向至 https://learn.chatgpt.com/docs/agent-configuration/agents-md

[2] OpenAI, Build skills.
https://developers.openai.com/codex/skills/
核对时重定向至 https://learn.chatgpt.com/docs/build-skills

包中研究流程是针对用户目标的执行规范，不声称首创某种科研方法，也不保证固定资源内产出或期刊接收。

## v1.2 增补与当前状态

新增 [阶段性新上下文探索](.agents/skills/physics-discovery-loop/references/fork-and-flush.md)，来源为 Cai et al. arXiv:2610.07447v1。主协议、项目入口和 START 已连接该补充。前置审查、心智模型只作手段、文献查新和物理价值验收全部保留。

两项本项目适配：允许在授权方向内重新选择科学问题；用贡献证据而非单一 benchmark 分数决定后续投入。二者未由原论文或本包证明有效。

本次仅更新会话容器内的协议文件。没有调用 Codex、外部模型或用户设备，没有产生真实新上下文分支，没有新增物理实验或科研结论。静态文件检查不等于宿主行为测试。

官方子代理文档只能支持宿主可能具有相关能力，不能证明当前会话工具已支持：
https://learn.chatgpt.com/docs/agent-configuration/subagents
